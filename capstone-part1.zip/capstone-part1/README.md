# Capstone Part 1 — Data Ingestion and EDA

This is the first deliverable. It covers the business context, testable hypotheses, data ingestion, and early EDA.

Run everything locally in a clean Python environment. I used Python 3.10.

Quick start:
1) Install the requirements.  
2) Fetch and compile the JSON into a single table.  
3) Generate the daily and monthly aggregates used later in modeling.

Main commands:
```
pip install -r requirements.txt
python src/ingest.py --outdir data/compiled
python src/make_features.py --indir data/compiled --outdir data/features
```

Contents:
- `hypotheses.md` — what I’m testing and why it matters to revenue.  
- `src/ingest.py` — pulls JSON from the aavail repo and compiles into a single file.  
- `src/make_features.py` — builds daily and monthly aggregates plus helper features.  
- `notebooks/01_eda.ipynb` — quick visual pass over revenue, purchases, and views.  
- `reports/figures/` — charts exported from the notebook (add as you go).

Notes:
- The feature matrix in Part 1 stays at daily and monthly grain. Part 2 will handle the forecasting setup (next 30 days target).
