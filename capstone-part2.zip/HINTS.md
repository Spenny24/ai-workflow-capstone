# What we’re testing (kept short)

- We can predict **next‑30‑day revenue** per country with practical accuracy by looking at recent revenue patterns (last 7/14/30 days), activity signals (views, purchases), and calendar effects.
- Walk‑forward validation will give us a realistic error band. If MAE and MAPE are stable across folds, we’re safe to move to deployment work in Part 3.
