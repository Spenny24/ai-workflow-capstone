# Capstone – Part 2 (Modeling)

This adds a simple, reliable modeling scaffold to your repo. The idea is:
- define the target exactly the way the course asks (sum of revenue over the **next 30 days**)
- build a few sensible features from the past (7/14/30 day windows, day-of-week, month, country)
- compare a couple of baseline models with honest walk‑forward validation
- keep outputs simple: a table of scores + a plot that lets you eyeball the fit

## Quick start

> Assumes you already ran Part 1 and have `data/compiled/compiled.parquet` (or CSV).

1) Create the supervised dataset (features + target):
```
python src/prepare_target.py --compiled data/compiled/compiled.parquet --outdir data/features
```

This writes:
- `data/features/daily_supervised.parquet` – row per day per country with features and `target_next30_rev`

2) Train baselines with walk‑forward validation:
```
python src/train_baselines.py --data data/features/daily_supervised.parquet --outdir reports
```

This writes:
- `reports/baseline_scores.csv`
- `reports/fig-predictions.png` (last fold, one country for readability)
- `reports/part2_summary.md` (short narrative you can copy into Coursera)

3) (Optional) Open the notebook for a guided run-through:
```
jupyter notebook notebooks/02_modeling.ipynb
```

Everything is written in plain English, no robotic phrasing.
