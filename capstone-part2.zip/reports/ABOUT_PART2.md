# Part 2 – what changed from Part 1

- We defined a single target: **sum of revenue over the next 30 days**.
- We engineered a few sturdy features from the past that generalise well.
- We used walk‑forward validation so the scores reflect production reality.
- We kept the model set light: Linear, Ridge, Random Forest. Enough to set a baseline without overfitting the homework.

You can lift this text (or the generated file in `reports/part2_summary.md`) into Coursera.
