#!/usr/bin/env python3
import argparse, os, warnings
import numpy as np
import pandas as pd
from sklearn.model_selection import TimeSeriesSplit
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")

def mape(y_true, y_pred):
    y_true = np.asarray(y_true); y_pred = np.asarray(y_pred)
    mask = y_true != 0
    return (np.fabs((y_true[mask]-y_pred[mask]) / y_true[mask]).mean()) * 100

def load_data(path):
    if path.endswith(".parquet"):
        return pd.read_parquet(path)
    return pd.read_csv(path)

def make_xy(df, country=None):
    cols = [c for c in df.columns if c not in ["date","target_next30_rev"]]
    if country is not None:
        df = df[df["country"] == country].copy()
    # drop country string if present
    if "country" in cols:
        cols.remove("country")
    X = df[cols].copy()
    y = df["target_next30_rev"].values
    dates = pd.to_datetime(df["date"].values)
    return X, y, dates, df

def model_bank(random_state=42):
    return {
        "Linear": LinearRegression(),
        "Ridge": Ridge(alpha=1.0, random_state=random_state),
        "RF": RandomForestRegressor(
            n_estimators=400, max_depth=None, min_samples_leaf=2,
            n_jobs=-1, random_state=random_state),
    }

def walk_forward(X, y, dates, models, n_splits=5):
    tscv = TimeSeriesSplit(n_splits=n_splits)
    rows = []
    last_fold_preds = None
    for name, model in models.items():
        fold = 0
        last_fold_preds = None
        for train_idx, test_idx in tscv.split(X):
            fold += 1
            X_tr, X_te = X.iloc[train_idx], X.iloc[test_idx]
            y_tr, y_te = y[train_idx], y[test_idx]
            model.fit(X_tr, y_tr)
            pred = model.predict(X_te)
            rows.append({
                "model": name,
                "fold": fold,
                "MAE": mean_absolute_error(y_te, pred),
                "RMSE": mean_squared_error(y_te, pred, squared=False),
                "MAPE": mape(y_te, pred)
            })
            if fold == n_splits:
                last_fold_preds = (dates[test_idx], y_te, pred)
    return pd.DataFrame(rows), last_fold_preds

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--outdir", default="reports")
    ap.add_argument("--country", default=None, help="Optional: restrict to a single country for clarity in the plot")
    args = ap.parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    df = load_data(args.data)
    # choose a representative country for plotting if not set
    country = args.country or df["country"].value_counts().idxmax()
    X, y, dates, dfc = make_xy(df, country=country)

    models = model_bank()
    scores, last = walk_forward(X, y, dates, models, n_splits=5)
    scores.to_csv(os.path.join(args.outdir, "baseline_scores.csv"), index=False)
    print("Saved:", os.path.join(args.outdir, "baseline_scores.csv"))
    print(scores.groupby("model")[["MAE","RMSE","MAPE"]].mean().round(2))

    # Plot last fold predictions for the chosen country
    if last is not None:
        dte, yt, yp = last
        plt.figure(figsize=(12,5))
        plt.plot(dte, yt, label="actual")
        for name, model in models.items():
            # re-fit each model on full train within the last fold to get its preds (already done in loop, but we only kept the last)
            pass  # we will just plot the best model below
        # pick best by MAE on last fold
        last_fold = scores[scores.fold == scores.fold.max()]
        best = last_fold.sort_values("MAE").iloc[0]["model"]
        # recompute preds for the best model on last fold for plotting
        # Need to recalc train/test splits to get the exact test indices
        from sklearn.model_selection import TimeSeriesSplit
        tscv = TimeSeriesSplit(n_splits=5)
        fold = 0
        best_pred = None; best_dates=None; best_y=None
        for tr, te in tscv.split(X):
            fold += 1
            if fold == 5:
                m = model_bank()[best]
                m.fit(X.iloc[tr], y[tr])
                best_pred = m.predict(X.iloc[te])
                best_dates = dates[te]
                best_y = y[te]
                break
        plt.plot(best_dates, best_pred, label=f"pred ({best})")
        plt.title(f"Next‑30‑day revenue (last fold) – {country}")
        plt.xlabel("date"); plt.ylabel("rev_30d")
        plt.legend()
        fig_path = os.path.join(args.outdir, "fig-predictions.png")
        plt.tight_layout(); plt.savefig(fig_path, dpi=180)
        print("Saved:", fig_path)

    # brief narrative file
    md = []
    md.append("# Part 2 – quick summary\n")
    md.append(f"- Country plotted: **{country}**\n")
    avg = scores.groupby("model")[["MAE","RMSE","MAPE"]].mean().sort_values("MAE").round(2)
    md.append("\n## Average CV scores\n")
    md.append(avg.to_csv(index=True))
    md.append("\n**Notes:** Walk‑forward CV uses 5 splits. Target is the sum of revenue over the next 30 days. Features come from past 7/14/30‑day windows plus calendar indicators. This is designed to be a solid baseline for Part 3.\n")
    with open(os.path.join(args.outdir, "part2_summary.md"), "w") as f:
        f.write("\n".join(md))
    print("Saved:", os.path.join(args.outdir, "part2_summary.md"))

if __name__ == "__main__":
    main()
