#!/usr/bin/env python3
import argparse, os
import pandas as pd
import numpy as np

def load_compiled(path):
    if path.endswith(".parquet"):
        return pd.read_parquet(path)
    return pd.read_csv(path)

def build_supervised(df: pd.DataFrame) -> pd.DataFrame:
    # expected columns (from Part 1): timestamp/date, country, revenue, purchases, stream_views (names normalized)
    # Normalize column names just in case
    df = df.rename(columns={c: c.strip().lower() for c in df.columns})
    # date
    date_col = "date" if "date" in df.columns else "timestamp"
    df[date_col] = pd.to_datetime(df[date_col])
    # basic sanity
    for c in ["country","revenue"]:
        if c not in df.columns:
            raise ValueError(f"Missing required column: {c}")
    df["country"] = df["country"].astype(str)
    df = df.sort_values([ "country", date_col ])

    # cover optional columns
    if "purchases" not in df.columns:
        df["purchases"] = 0.0
    if "stream_views" not in df.columns and "total_views" in df.columns:
        df["stream_views"] = df["total_views"]
    if "stream_views" not in df.columns:
        df["stream_views"] = 0.0

    # daily per country
    daily = (df
        .groupby(["country", pd.Grouper(key=date_col, freq="D")])
        .agg(revenue=("revenue","sum"),
             purchases=("purchases","sum"),
             views=("stream_views","sum"))
        .reset_index()
        .rename(columns={date_col:"date"})
    )

    # fill missing days per country
    all_rows = []
    for country, g in daily.groupby("country"):
        full_idx = pd.date_range(g["date"].min(), g["date"].max(), freq="D")
        g = g.set_index("date").reindex(full_idx).fillna(0.0)
        g.index.name = "date"
        g["country"] = country
        all_rows.append(g.reset_index())
    daily = pd.concat(all_rows, ignore_index=True)

    # calendar features
    daily["dow"] = daily["date"].dt.dayofweek
    daily["month"] = daily["date"].dt.month

    # rolling features (past windows)
    def add_roll(g):
        g = g.sort_values("date")
        for k in [7,14,30]:
            g[f"rev_lag{k}"] = g["revenue"].shift(1).rolling(k).sum()
            g[f"purch_lag{k}"] = g["purchases"].shift(1).rolling(k).sum()
            g[f"views_lag{k}"] = g["views"].shift(1).rolling(k).sum()
        # target: next 30‑day revenue (sum forward, exclude today)
        g["target_next30_rev"] = g["revenue"].shift(-1).rolling(30).sum()
        return g

    daily = daily.groupby("country", group_keys=False).apply(add_roll)

    # drop rows with NaNs due to rolling at edges
    daily = daily.dropna().reset_index(drop=True)

    # One‑hot month and dow (compact)
    daily = pd.get_dummies(daily, columns=["dow","month"], drop_first=True)

    return daily

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--compiled", required=True, help="Path to compiled.parquet/CSV from Part 1")
    ap.add_argument("--outdir", default="data/features")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    df = load_compiled(args.compiled)
    sup = build_supervised(df)
    outpath = os.path.join(args.outdir, "daily_supervised.parquet")
    sup.to_parquet(outpath, index=False)
    print(f"Wrote {outpath} with {len(sup):,} rows and {sup.shape[1]} columns")
    # tiny csv head for quick peek
    sup.head(200).to_csv(os.path.join(args.outdir, "daily_supervised_sample.csv"), index=False)
    print("Sample -> daily_supervised_sample.csv")

if __name__ == "__main__":
    main()
